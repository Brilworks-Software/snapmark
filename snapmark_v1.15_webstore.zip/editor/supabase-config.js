// editor/supabase-config.js
// IMPORTANT: Do not commit this file to Git! 
// This file contains your Supabase credentials.

const SUPABASE_CONFIG = {
  url: 'https://xagpojleqdfyxpxxtfzw.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhhZ3BvamxlcWRmeXhweHh0Znp3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzczNTEzMTAsImV4cCI6MjA5MjkyNzMxMH0.tRqZHUCAoBJdqZJ8Iqi8ocwA6fFjoaarv06VthrAL7U'
};
